# HR Pulse Dashboard

## Projektübersicht

**HR Pulse** ist ein Streamlit-basiertes HR-Analytics-Dashboard für eine süddeutsche Sparkasse/Bank. Es bietet umfassende Personalanalysen mit Fokus auf Kapazitätssteuerung, Demografie, Altersteilzeit und Forecasting.

### Kernfeatures
- 6 Module: Überblick, Demografie, Altersteilzeit, Organisationseinheiten, Jobfamilies, Simulation
- Globaler MAK ↔ Euro Toggle (beeinflusst alle Visuals)
- Flexible Filter (Zeit, Alter, OrgEinheit, Geschlecht, etc.)
- Frei definierbare Alterskohorten
- Segment-Builder für Schnittmengen-Analysen
- Forecast/Simulation mit Szenariovergleich

---

## Tech Stack

```
Python 3.11+
streamlit >= 1.36.0
pandas >= 2.0
plotly >= 5.18
openpyxl >= 3.1
numpy >= 1.24
```

### Styling
- Dunkles Theme (Slate/Navy Basis)
- Akzentfarben: Teal (#14b8a6), Amber (#f59e0b), Coral (#f87171)
- Konsistente Farbkodierung: Grün=gut, Amber=Warnung, Rot=kritisch

---

## Projektstruktur

```
hr_pulse/
├── app.py                      # Haupteinstieg, st.navigation Setup
├── requirements.txt
├── .streamlit/
│   └── config.toml             # Theme-Konfiguration
├── config/
│   ├── settings.py             # Globale Konstanten, Defaults
│   ├── cohorts.json            # Persistierte Kohorten-Definitionen
│   └── segments.json           # Gespeicherte Segmente
├── data/
│   ├── loader.py               # Excel/CSV Loader mit @st.cache_data
│   ├── transformer.py          # Datenaufbereitung, Berechnungen
│   ├── synthetic.py            # Generator für synthetische Testdaten
│   └── sample_data/
│       └── hr_data.xlsx        # Generierte Testdaten
├── components/
│   ├── __init__.py
│   ├── sidebar.py              # Globale Filter-Sidebar
│   ├── kpi_card.py             # Wiederverwendbare KPI-Card Komponente
│   ├── charts.py               # Chart-Factory (alle Plotly-Charts)
│   ├── toggle.py               # MAK/Euro Toggle Komponente
│   └── segment_builder.py      # Schnittmengen-Tool UI
├── pages/
│   ├── 1_🏠_Uebersicht.py
│   ├── 2_👥_Demografie.py
│   ├── 3_🔄_Altersteilzeit.py
│   ├── 4_🏢_Organisationseinheiten.py
│   ├── 5_💼_Jobfamilies.py
│   └── 6_📈_Simulation.py
├── utils/
│   ├── __init__.py
│   ├── calculations.py         # MAK/Euro Umrechnung, KPI-Berechnungen
│   ├── forecast.py             # Simulationslogik, Monte-Carlo
│   ├── filters.py              # Filter-Logik, Query-Building
│   └── export.py               # CSV/Excel Export-Funktionen
└── assets/
    ├── style.css               # Custom CSS
    └── logo.svg                # Dashboard Logo
```

---

## Datenmodell

### Primäre Datenquellen (aus Excel)

#### 1. Snapshot_Detail (Haupttabelle)
Die zentrale Fakten-Tabelle mit einer Zeile pro Planstelle.

| Spalte | Typ | Beschreibung |
|--------|-----|--------------|
| Kürzel OrgEinheit | str | Org-Einheit Kürzel (z.B. "826") |
| OrgEinheitNr | float | Numerische ID |
| Organisationseinheit | str | Name der Einheit |
| Planstellennr | float | Eindeutige Planstellen-ID |
| Planstelle | str | Bezeichnung der Stelle |
| Sollarbeitszeit | float | Wochenstunden Soll |
| Bewertung Tarifgruppe | str | Tarifgruppe der Stelle (E6-E15) |
| Personalnummer | float | MA-ID (NaN = vakant) |
| Soll_FTE | float | Soll-Kapazität in FTE |
| PersNr | float | Verknüpfung zu Person |
| GebDatum | datetime | Geburtsdatum |
| Text Gsch | str | Geschlecht (männlich/weiblich) |
| Eintritt | datetime | Eintrittsdatum |
| Austritt | datetime | Austrittsdatum (falls vorhanden) |
| BsGrd | float | Beschäftigungsgrad (0-100) |
| Vertragsart | str | Unbefristet/Zeitvertrag/Altersteilzeit |
| Status kundenindividuell | str | Aktiv/Ruhend |
| Tarifarttext | str | TVÖD/Auszubildende-VKA/etc. |
| TrfGr | str | Aktuelle Tarifgruppe Person |
| St | str | Tarifstufe (1-6) |
| FTE_person | float | Ist-FTE der Person |
| Total_Cost_Year | float | Jahreskosten in € |
| Is_Vacant | bool | True wenn Stelle unbesetzt |
| FTE_assigned | float | Zugewiesene FTE |

#### 2. History_Cube (Zeitreihen)
Monatliche Snapshots pro OrgEinheit.

| Spalte | Typ | Beschreibung |
|--------|-----|--------------|
| Kürzel OrgEinheit | str | Org-Einheit |
| Headcount | int | Anzahl Köpfe |
| Total_Cost | float | Gesamtkosten € |
| FTE | float | FTE Summe |
| Vacancy_Count | int | Anzahl Vakanzen |
| Date | datetime | Monatsstichtag |

#### 3. Organisationsstruktur (Hierarchie)
Mapping der Org-Einheiten.

| Spalte | Typ | Beschreibung |
|--------|-----|--------------|
| Kürzel OrgEinheit | str | Kürzel |
| OrgEinheitNr | float | ID |
| Organisationseinheit | str | Name |

### Berechnete Metriken

```python
# MAK (Mitarbeiterkapazität) = FTE
MAK = df['FTE_assigned'].sum()

# Headcount = Anzahl Personen (nicht Stellen)
HC = df[df['PersNr'].notna()]['PersNr'].nunique()

# Besetzungsgrad
Besetzungsgrad = besetzte_stellen / alle_stellen

# Teilzeitquote
TZ_Quote = df[df['FTE_person'] < 0.95].shape[0] / HC

# ATZ-Quote
ATZ_Quote = df[df['Vertragsart'] == 'Altersteilzeit'].shape[0] / HC

# Durchschnittskosten pro FTE
Avg_Cost_FTE = df['Total_Cost_Year'].sum() / MAK
```

---

## Globale Filter (Session State)

```python
# In st.session_state zu speichern:
{
    "view_mode": "MAK",  # oder "Euro"
    "date_range": (date_min, date_max),
    "selected_org_units": [],  # Liste von Kürzeln
    "selected_cohorts": [],  # Liste von Kohorten-Namen
    "selected_genders": ["m", "w"],
    "selected_employment": ["Vollzeit", "Teilzeit"],
    "selected_education": [],
    "selected_atz_status": ["Kein ATZ", "Arbeitsphase", "Freistellungsphase"],
    "cohort_definitions": {
        "Azubis": (16, 19),
        "Young Professionals": (20, 29),
        "Mid Career": (30, 44),
        "Senior": (45, 54),
        "Pre-Retirement": (55, 62),
        "Retirement Ready": (63, 99)
    }
}
```

---

## Modul-Spezifikationen

### Modul 1: Überblick

**Pfad:** `pages/1_🏠_Uebersicht.py`

**Layout:**
1. KPI-Row (4 Cards): Gesamt-MAK/Euro, Besetzungsgrad (Gauge), Vakanz, ATZ-Quote
2. Stacked Area Chart: Kapazität nach Alterskohorte über Zeit
3. 2-Column: Donut Arbeitszeit | Donut Geschlecht
4. Horizontal Bar: Top 5 OrgEinheiten
5. Alert-Banner: Automatische Warnungen

**KPI-Card Spezifikation:**
```python
def kpi_card(title, value, subtitle, trend=None, sparkline_data=None, status=None):
    """
    title: str - Überschrift
    value: str - Hauptwert (formatiert)
    subtitle: str - Zusatzinfo
    trend: tuple(float, str) - (Wert, "vs VJ"/"vs VM")
    sparkline_data: list - Werte für Mini-Chart
    status: str - "good"/"warning"/"critical" für Farbkodierung
    """
```

### Modul 2: Demografie

**Pfad:** `pages/2_👥_Demografie.py`

**Tabs:**
1. **Alter**: Population Pyramid, Kohorten-Tabelle, Qualifikation×Alter Stacked Bar
2. **Geschlecht**: Donut mit Benchmark, Grouped Bar Geschlecht×Kohorte, Heatmap Geschlecht×Ausbildung
3. **Qualifikation**: Treemap, Stacked Bar Qualifikation×Alter
4. **Arbeitszeit**: VZ/TZ KPIs, Grouped Bar nach Kohorte, Scatter Alter vs. Beschäftigungsgrad

### Modul 3: Altersteilzeit

**Pfad:** `pages/3_🔄_Altersteilzeit.py`

**Elemente:**
1. KPI-Row: ATZ Gesamt, Arbeitsphase, Freistellungsphase
2. Funnel: Gesamtbelegschaft → ATZ-berechtigt → In ATZ → Phasen
3. 2-Column: Gantt Timeline ATZ-Verläufe | Stacked Bar ATZ nach Org
4. Line Chart: ATZ-Quote über Zeit
5. Detail-Tabelle mit Export

### Modul 4: Organisationseinheiten

**Pfad:** `pages/4_🏢_Organisationseinheiten.py`

**Elemente:**
1. Breadcrumb-Navigation
2. Sunburst: Org-Hierarchie (Größe=MAK, Farbe=Besetzungsgrad)
3. KPI-Row für ausgewählte Einheit: Soll, Ist, Varianz absolut, Varianz relativ
4. 2-Column: Waterfall Soll→Ist | Diverging Lollipop Untereinheiten
5. Detail-Tabelle mit Drill-through

### Modul 5: Jobfamilies

**Pfad:** `pages/5_💼_Jobfamilies.py`

**Tabs:**
1. **Analyse**: Treemap, Radar-Profil, Heatmap Jobfamily×Org
2. **Definition**: Editor für Jobfamily-Zuordnungen, Unmapped-Liste
3. **Qualifikationen**: Mindestanforderungen, Gap-Analyse

**Jobfamily-Mapping Struktur:**
```python
{
    "Kundenberatung": {
        "patterns": ["Kundenberater*", "Privatkundenber*", "Firmenkundenber*"],
        "min_qualification": "Bankfachwirt",
        "version": "v2",
        "valid_from": "2026-01-01"
    },
    ...
}
```

### Modul 6: Simulation

**Pfad:** `pages/6_📈_Simulation.py`

**Parameter-Panel:**
- Horizont: 1-10 Jahre (Slider)
- Szenario A/B Vergleich
- Rentenaustritte: Alter, Frühverrentungs-%
- Fluktuation: Raten pro Alterskohorte
- Azubi-Übernahme: Anzahl, Dauer, Übernahmerate
- Neueinstellungen: Hiring-Rate, Time-to-Fill

**Forecast-Logik:**
```python
def simulate_workforce(
    base_df: pd.DataFrame,
    horizon_months: int,
    params: SimulationParams
) -> pd.DataFrame:
    """
    Simuliert Personalentwicklung monatsweise.
    
    Abgänge:
    - Rente: Alle mit Alter >= Rentenalter zum Monatsende
    - Fluktuation: Zufällig nach Kohorten-Rate
    - ATZ-Freistellung: Übergang wenn Arbeitsphase endet
    
    Zugänge:
    - Azubi-Übernahme: Nach Ausbildungsdauer mit Übernahmerate
    - Neueinstellungen: Hiring-Rate × Vakanzen mit Time-to-Fill Verzögerung
    
    Returns: DataFrame mit monatlichen Snapshots
    """
```

---

## Komponenten-Spezifikationen

### sidebar.py

```python
def render_global_filters():
    """
    Rendert die komplette Filter-Sidebar.
    Speichert alle Werte in st.session_state.
    Gibt gefilterten DataFrame zurück.
    """
    
def render_cohort_editor():
    """
    Modal/Expander zum Bearbeiten der Alterskohorten.
    Speichert in config/cohorts.json.
    """

def apply_filters(df: pd.DataFrame) -> pd.DataFrame:
    """
    Wendet alle aktiven Filter auf DataFrame an.
    """
```

### charts.py

```python
def create_kpi_card(title, value, ...) -> st.container:
    """Erzeugt eine gestylte KPI-Card mit HTML/CSS."""

def create_population_pyramid(df, age_col, gender_col, value_col) -> go.Figure:
    """Bevölkerungspyramide mit Plotly."""

def create_sunburst(df, path_cols, value_col, color_col) -> go.Figure:
    """Sunburst für Org-Hierarchie."""

def create_waterfall(categories, values, title) -> go.Figure:
    """Waterfall-Chart für Soll→Ist Brücken."""

def create_diverging_bar(df, category_col, value_col) -> go.Figure:
    """Divergierender Balken für Varianzen."""

def create_heatmap(df, x_col, y_col, value_col) -> go.Figure:
    """Heatmap für Matrix-Darstellungen."""

def create_forecast_area(df, date_col, value_col, forecast_start) -> go.Figure:
    """Area Chart mit Historie/Prognose Trennung."""
```

### segment_builder.py

```python
def render_segment_builder():
    """
    UI für Schnittmengen-Analysen.
    Ermöglicht beliebige Merkmalskombinationen.
    Zeigt Ergebnis (Anzahl, MAK, Euro).
    Speichern/Laden von Segmenten.
    """

def calculate_segment(df, conditions: list[dict]) -> pd.DataFrame:
    """
    conditions: [
        {"column": "age_cohort", "operator": "in", "values": ["55-62", "63+"]},
        {"column": "education", "operator": "==", "value": "Bankbetriebswirt"},
        ...
    ]
    """
```

---

## Synthetische Testdaten

### Generator-Anforderungen

Erstelle realistische Testdaten für eine Bank mit ~1.200 Mitarbeitenden.

```python
# data/synthetic.py

def generate_synthetic_data(
    n_employees: int = 1200,
    n_planstellen: int = 1700,
    start_date: str = "2024-01-01",
    end_date: str = "2026-01-18"
) -> dict[str, pd.DataFrame]:
    """
    Generiert alle benötigten DataFrames.
    
    Returns:
        {
            "snapshot_detail": pd.DataFrame,
            "history_cube": pd.DataFrame,
            "org_structure": pd.DataFrame
        }
    """
```

### Datenverteilungen

```python
# Altersverteilung (realistisch für Bank)
age_distribution = {
    (16, 19): 0.07,   # Azubis
    (20, 29): 0.22,
    (30, 39): 0.16,
    (40, 49): 0.20,
    (50, 59): 0.25,
    (60, 69): 0.10
}

# Geschlechterverteilung
gender_distribution = {"w": 0.63, "m": 0.37}

# Beschäftigungsgrad
employment_distribution = {
    1.0: 0.67,      # Vollzeit
    0.75: 0.12,
    0.50: 0.15,
    0.25: 0.06
}

# Tarifgruppen
tariff_distribution = {
    "E6": 0.05, "E7": 0.08, "E8": 0.12,
    "E9A": 0.15, "E9B": 0.10, "E9C": 0.18,
    "E10": 0.14, "E11": 0.10, "E12": 0.04,
    "E13": 0.02, "E14": 0.01, "E15": 0.01
}

# Organisationseinheiten
org_units = [
    {"kuerzel": "025", "name": "Privatkunden Region Nord", "target_size": 45},
    {"kuerzel": "026", "name": "Privatkunden Region Süd", "target_size": 42},
    {"kuerzel": "028", "name": "Firmenkunden", "target_size": 55},
    {"kuerzel": "030", "name": "Baufinanzierung", "target_size": 35},
    {"kuerzel": "191", "name": "Vertriebssteuerung", "target_size": 60},
    {"kuerzel": "826", "name": "Marktfolge Kredit", "target_size": 85},
    {"kuerzel": "840", "name": "Controlling & Rechnungswesen", "target_size": 40},
    {"kuerzel": "815", "name": "Facility Management", "target_size": 25},
    {"kuerzel": "850", "name": "Marketing", "target_size": 30},
    {"kuerzel": "900", "name": "Compliance", "target_size": 15},
    {"kuerzel": "411", "name": "IT & Organisation", "target_size": 65},
    {"kuerzel": "330", "name": "Personal", "target_size": 20},
    # ... weitere Einheiten
]

# Qualifikationsgruppen
education_distribution = {
    "derzeit Berufsausbildung": 0.09,
    "kfm Berufsabschluss": 0.19,
    "Bankberufsabschluss": 0.17,
    "Sparkassen/Bankfachwirt": 0.17,
    "SPK/Bankbetriebswirt": 0.21,
    "Bachelor FH": 0.08,
    "Bachelor Universität": 0.01,
    "Master FH": 0.02,
    "Master Universität": 0.03,
    "ohne Berufsabschluss": 0.01,
    "nicht kfm Berufsabschluss": 0.02
}

# ATZ-Verteilung (unter 55+)
atz_rate_55plus = 0.23  # 23% der 55+ in ATZ
atz_phase_split = {"Arbeitsphase": 0.5, "Freistellungsphase": 0.5}

# Vakanzrate pro OrgEinheit (variabel)
vacancy_rate_range = (0.15, 0.35)  # 15-35% Vakanzen
```

### Kostenberechnung

```python
# Basis-Jahresgehälter nach Tarifgruppe (TVöD-S, Stufe 4)
base_salary = {
    "E6": 42000, "E7": 45000, "E8": 48000,
    "E9A": 52000, "E9B": 54000, "E9C": 56000,
    "E10": 60000, "E11": 65000, "E12": 72000,
    "E13": 78000, "E14": 85000, "E15": 95000
}

# Stufenzuschläge (kumulativ)
step_multiplier = {1: 0.85, 2: 0.92, 3: 0.97, 4: 1.0, 5: 1.05, 6: 1.12}

# Arbeitgeberkosten-Faktor
employer_cost_factor = 1.25

# Total Cost = base_salary * step_multiplier * FTE * employer_cost_factor
```

---

## Implementierungsreihenfolge

### Phase 1: Foundation (Tag 1)
1. Projektstruktur anlegen
2. `requirements.txt` und `.streamlit/config.toml`
3. `data/synthetic.py` - Testdaten-Generator
4. `data/loader.py` - Daten laden mit Caching
5. `app.py` - Navigation Setup

### Phase 2: Komponenten (Tag 2)
1. `components/sidebar.py` - Globale Filter
2. `components/toggle.py` - MAK/Euro Toggle
3. `components/kpi_card.py` - KPI-Cards
4. `components/charts.py` - Basis-Charts
5. `assets/style.css` - Custom Styling

### Phase 3: Überblick (Tag 3)
1. `pages/1_🏠_Uebersicht.py` komplett
2. Alle KPIs, Charts, Alerts

### Phase 4: Demografie (Tag 4)
1. `pages/2_👥_Demografie.py`
2. Alle 4 Tabs implementieren
3. Population Pyramid, Heatmaps

### Phase 5: ATZ + Org (Tag 5-6)
1. `pages/3_🔄_Altersteilzeit.py`
2. `pages/4_🏢_Organisationseinheiten.py`
3. Sunburst, Drill-down Logik

### Phase 6: Jobfamilies (Tag 7)
1. `pages/5_💼_Jobfamilies.py`
2. Editor für Definitionen
3. Persistenz in JSON

### Phase 7: Simulation (Tag 8-9)
1. `utils/forecast.py` - Simulationslogik
2. `pages/6_📈_Simulation.py`
3. Szenariovergleich

### Phase 8: Segment-Builder + Polish (Tag 10)
1. `components/segment_builder.py`
2. Export-Funktionen
3. Finales Styling
4. Testing

---

## Coding-Standards

### Streamlit Best Practices
- `@st.cache_data` für alle Datenlade-Funktionen
- `st.session_state` für alle Filter und Zustände
- Keine globalen Variablen außerhalb von Session State
- `st.fragment` für unabhängige UI-Bereiche (Performance)

### Chart-Standards
- Alle Charts via Plotly Graph Objects (nicht Express)
- Konsistentes Farbschema aus `config/settings.py`
- Hover-Templates mit deutschen Beschriftungen
- Responsive: `fig.update_layout(autosize=True)`

### Daten-Standards
- Alle Datumsfelder als `pd.Timestamp`
- Alle Geldbeträge in Euro (float)
- Alle FTE-Werte als float mit 4 Dezimalstellen
- Fehlende Werte: `np.nan`, nicht None oder ""

### Dokumentation
- Docstrings für alle Funktionen (Google-Style)
- Type Hints für alle Parameter und Returns
- Kommentare nur wo Logik nicht offensichtlich

---

## Wichtige Hinweise

1. **MAK/Euro Toggle**: Muss ALLE Visuals auf ALLEN Seiten beeinflussen. Zentrale Umrechnung in `utils/calculations.py`.

2. **Alterskohorten**: Müssen dynamisch sein und aus `st.session_state['cohort_definitions']` gelesen werden. Alle Berechnungen müssen diese verwenden.

3. **Jobfamily-Mapping**: Initial sind alle als "UNMAPPED" markiert. Der Editor muss Pattern-Matching (Wildcards) unterstützen.

4. **Simulation**: Muss deterministisch sein (Seed für Reproduzierbarkeit), aber auch Monte-Carlo für Konfidenzbänder unterstützen.

5. **Performance**: Bei ~1.700 Zeilen ist Performance unkritisch, aber Caching trotzdem sauber implementieren für Skalierbarkeit.

---

## Beispiel-Kommandos für Claude Code

```bash
# Projekt initialisieren
claude "Erstelle die Projektstruktur gemäß CLAUDE.md"

# Testdaten generieren
claude "Implementiere data/synthetic.py und generiere realistische Testdaten"

# Einzelne Seite implementieren
claude "Implementiere pages/1_🏠_Uebersicht.py mit allen KPIs und Charts"

# Komponente entwickeln
claude "Erstelle components/charts.py mit create_population_pyramid Funktion"

# Bug fixen
claude "Der Besetzungsgrad wird falsch berechnet - analysiere und behebe"
```
